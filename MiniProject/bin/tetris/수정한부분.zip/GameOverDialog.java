package tetris;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class GameOverDialog extends JDialog{
	GameOverDialog god = this;
	//IcecreamDialog ice;
	Tetris tetris;
	GridBagConstraints gbc = new GridBagConstraints();
	private int x = 0;
	private int y = 0;

	private JPanel background = new JPanel(new GridBagLayout());

	private CardLayout cl = new CardLayout();
	private CardLayout cl2 = new CardLayout();
	private JPanel cardPanel = new JPanel(cl);
	private JPanel cardPanel2 = new JPanel(cl2);
	private JPanel imgPanel = new JPanel(new BorderLayout(5,5));
	private JPanel rankPanel = new JPanel(new GridBagLayout());
	private JPanel btnPanel = new JPanel(new GridBagLayout());
	private JPanel namePanel = new JPanel(new GridBagLayout());


	private JButton btnRe = new JButton("다시 시작");
	private JButton btnRank = new JButton("랭킹보기");
	private JButton btnMenu = new JButton("메뉴로 돌아가기");
	private JButton btnExit = new JButton("게임종료");
	private JButton btnOk = new JButton("등 록");

	private JLabel msg = new JLabel("축하합니다! 순위에 랭크되었습니다.");
	private JTextField nameField = new JTextField("");

	private JButton[] btns = new JButton[] {btnRe, btnRank, btnMenu, btnExit, btnOk};
	GameOver gosco = new GameOver();
	private void setXY(int x, int y) {
		gbc.gridx = x;
		gbc.gridy = y;
		this.x = x;
		this.y = y;
		gbc.weightx = 1.0;
	}
	int count = 0;
	private void eventInit() {
		btnRe.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				god.dispose();
			}
		});
		btnRank.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cl.show(cardPanel, "rank");
			}
		});
		btnMenu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//	ice.dispose();
				tetris.dispose();
				god.dispose();
			}
		});
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnOk.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(count==0) {
					cl2.show(cardPanel2, "btn");
					//String name = nameField.getText();
					gosco.rankDialog();
				}else {
				   System.out.println("이미등록이 되어있습니다.");
				}
				count++;
				
			}
		});
	}

	private void showRank() {
		for(int i = 0; i < 5; i++) {
			//			String str = i+1+"위\t" + IcecreamDialog.sr.rankList.get(i).getName() + "\t" + IcecreamDialog.sr.rankList.get(i).getScore();
			//			JLabel rank = new JLabel(str);
			//
			//			rankPanel.add(rank, gbc);
		}
	}

	private void compInit() {
		background = new JPanel() {
			public void paintComponent(Graphics g) {
				setOpaque(false);
				super.paintComponent(g);
			}
		};
		this.setFocusable(true);
		this.requestFocusInWindow();
		background.setLayout(new BorderLayout());

		JLabel gameover = new JLabel(new ImageIcon("resources/gameover.png"));
		imgPanel.add(gameover);


		//	--	gameover.setOpaque(false);
		//	--	imgPanel.setOpaque(false);
		//	--	rankPanel.setOpaque(false);
		//	--	cardPanel.setOpaque(false);
		//--		btnPanel.setOpaque(false);

		cl.setVgap(10);
		cardPanel.add("img", imgPanel);
		cardPanel.add("rank", rankPanel);

		//-----------------------------------------------------------

//		for(int i = 0; i < btns.length; i++) {
//			btns[i].setPreferredSize(new Dimension(130, 30));
//			btns[i].setOpaque(false);
//			setXY(0, i);
//			btnPanel.add(btns[i], gbc);
//		}
		//{btnRe, btnRank, btnMenu, btnExit, btnOk};
		setXY(0, 0);
		btnPanel.add(btnRe,gbc);
		setXY(0, 1);
		btnPanel.add(btnRank,gbc);
		setXY(0, 2);
		btnPanel.add(btnMenu,gbc);
		setXY(0, 3);
		btnPanel.add(btnExit,gbc);
		setXY(0, 4);
		btnPanel.add(btnOk,gbc);
		
		gbc.insets = new Insets(2, 0, 2, 0);
		nameField.setPreferredSize(new Dimension(130, 30));
//		setXY(0,0);
//		namePanel.add(msg, gbc);
//		setXY(0,1);
//		namePanel.add(nameField, gbc);
//		setXY(0,2);
//		namePanel.add(btnOk, gbc);

		//	--	cardPanel2.add("name", namePanel);
		cardPanel2.add("btn", btnPanel);


		background.add(cardPanel2);
		background.add(cardPanel, BorderLayout.NORTH);
		this.getContentPane().add(background,0);
	}
	
//	public void rankDialog()
//	{
//		
//		String name = field.getText();
//		if(name.equals("")) {
//			name="unknown";
//		}
//		int sco ;
//		sco = Integer.parseInt(Tetris.statusbar2.getText());
//		ScoreRanking sr = new ScoreRanking(sco, name);
//		try {
//			 sr.saveTxt();
//			 sr.readTxt();
//			 System.out.println(name);
//		} catch (Exception e) {
//			System.out.println("숫자가 아님");
//		}
//	}

	//public GameOverDialog(int score, Tetris parent) {
      public GameOverDialog(int score) {
			//tetris = parent;
			this.setSize(270,500);
			this.setLocationRelativeTo(null);
			this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
			this.setLayout(new BorderLayout());
			compInit();
			eventInit();
			this.setModal(true);
			this.setUndecorated(true);
			this.setVisible(true);
		}
}

