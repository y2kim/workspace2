package fly.avoidBomb;

public class GameExitException extends Exception{
	public GameExitException(String msg) {
		super(msg);
	}
}
