package fly.dodge;

public class GameExitException extends Exception{
	public GameExitException(String msg) {
		super(msg);
	}
}
